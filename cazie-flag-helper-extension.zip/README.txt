Cazie's Flag Challenge Helper — Chrome unpacked extension

Install:
1. Extract the ZIP, if using the ZIP copy.
2. Open chrome://extensions in Chrome.
3. Turn on Developer mode.
4. Choose Load unpacked and select this folder (the folder containing manifest.json).
5. Disable/remove the old Tampermonkey copy so two copies do not run on the same page.

The extension injects the helper only on https://cazie-s.onrender.com/.
Automatic retries call Chrome's cache-bypassing tab reload API. Click the extension toolbar button to hard-refresh the current tab, or use Ctrl+Shift+Y. Change the shortcut at chrome://extensions/shortcuts.
