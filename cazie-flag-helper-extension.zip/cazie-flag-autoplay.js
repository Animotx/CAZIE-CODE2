// ==UserScript==
// @name         Cazie's Flag Challenge Helper
// @namespace    local.cazie.flag-helper
// @version      3.4.0
// @description  Automatically handle saved-credential login, recoverable activation/login retries, navigation, and the flag challenge.
// @match        https://cazie-s.onrender.com/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(() => {
  'use strict';

  // Requires Chrome's password manager or an existing authenticated session for sign-in.
  // The activation code is entered only on this site's activation form.
  const KEY = '__cazieFlagHelper';
  if (window[KEY]) return;
  // Remove the one-use cache-buster after the new document has loaded.
  const loadedUrl = new URL(location.href);
  if (loadedUrl.searchParams.has('__cazie_retry')) {
    loadedUrl.searchParams.delete('__cazie_retry');
    history.replaceState(history.state, '', loadedUrl.href);
  }
  const ACTIVATION_CODE = 'CAZIE-BX5Y-8WL';

  const state = { running: true, userPaused: false, busy: false, queue: [], delay: 1000, timer: 0, catalog: null, nameMap: null, fallbackIndex: Number(localStorage.getItem('cazie_flag_fallback_index') || 0) };
  const panel = document.createElement('section');
  panel.id = 'cazie-flag-helper';
  panel.setAttribute('popover', 'manual');
  panel.innerHTML = `
    <header><strong>Flag helper</strong><button type="button" data-min aria-label="Minimize">−</button></header>
    <div class="body">
      <label><input data-auto type="checkbox" checked> Identify flags automatically</label>
      <small>Compares Flagpedia and flag-icons SVGs. If confidence is low, it pauses instead of guessing.</small>
      <label>Optional answer queue (one per line)</label>
      <textarea data-answers rows="3" placeholder="Used instead of recognition when provided"></textarea>
      <label>Wait between actions (seconds)</label>
      <input data-delay type="number" min="1" max="120" step="1" value="1">
      <div class="buttons"><button type="button" data-start>Start</button><button type="button" data-pause disabled>Pause</button></div>
      <div data-status role="status">Auto-login and navigation are starting…</div>
      <ol data-log></ol>
      <small>Reference sites:
        <a href="https://www.countryflags.com/" target="_blank" rel="noopener">CountryFlags.com</a> ·
        <a href="https://flagpedia.net/" target="_blank" rel="noopener">Flagpedia</a> ·
        <a href="https://worldflags.net/" target="_blank" rel="noopener">WorldFlags.net</a> ·
        <a href="https://worldflagmap.com/" target="_blank" rel="noopener">World Flag Map</a>
      </small>
    </div>`;
  const style = document.createElement('style');
  style.textContent = `
    #cazie-flag-helper{position:fixed!important;inset:auto 18px 18px auto!important;z-index:2147483647!important;isolation:isolate;pointer-events:auto!important;touch-action:manipulation;width:290px;max-height:75vh;overflow:hidden;background:#fff;color:#24191c;border:1px solid #e9b8c4;border-radius:14px;box-shadow:0 8px 32px #32101c38;font:13px/1.4 system-ui,sans-serif}
    #cazie-flag-helper *{box-sizing:border-box} #cazie-flag-helper header{display:flex;justify-content:space-between;align-items:center;padding:10px 13px;background:#cc4e69;color:#fff}
    #cazie-flag-helper button{pointer-events:auto!important;cursor:pointer;border:0;border-radius:7px;padding:7px 10px;background:#cc4e69;color:white;font-weight:700} #cazie-flag-helper button:disabled{opacity:.45;cursor:default}
    #cazie-flag-helper header button{padding:0 7px;background:#ffffff30;font-size:18px} #cazie-flag-helper .body{padding:12px;overflow:auto;max-height:calc(75vh - 42px)}
    #cazie-flag-helper label{display:block;margin:8px 0 4px;font-weight:650} #cazie-flag-helper textarea,#cazie-flag-helper input{width:100%;padding:8px;border:1px solid #e8c4cc;border-radius:7px;font:inherit;background:#fffafa;color:#24191c} #cazie-flag-helper [data-auto]{width:auto;vertical-align:middle} #cazie-flag-helper small{display:block;color:#635057}
    #cazie-flag-helper .buttons{display:flex;gap:8px;margin-top:10px} #cazie-flag-helper [data-pause]{background:#6b5b60}
    #cazie-flag-helper [data-status]{margin-top:9px;color:#635057} #cazie-flag-helper ol{padding-left:22px;max-height:135px;overflow:auto;margin:7px 0 0} #cazie-flag-helper li{margin:4px 0;overflow-wrap:anywhere}
    #cazie-flag-helper.min .body{display:none}`;
  document.documentElement.append(style, panel);
  try { if (typeof panel.showPopover === 'function' && !panel.matches(':popover-open')) panel.showPopover(); } catch {}
  const $ = (sel) => panel.querySelector(sel);
  const status = (msg) => {
    if (state.userPaused && msg !== 'Paused.') return;
    const el = $('[data-status]');
    if (el.textContent !== msg) el.textContent = msg;
  };
  const log = (answer, result) => {
    const li = document.createElement('li');
    li.textContent = `${answer} — ${result}`;
    $('[data-log]').prepend(li);
  };
  const delay = () => new Promise((resolve) => { state.timer = window.setTimeout(resolve, state.delay); });
  const isChallenge = () => [...document.querySelectorAll('h1,h2')].some((el) => /Which Country Does This Flag Belong To\?/i.test(el.textContent));
  const waitFor = async (fn, timeout = 180000) => {
    const end = Date.now() + timeout;
    while (Date.now() < end && state.running) {
      const value = fn();
      if (value) return value;
      await new Promise((r) => setTimeout(r, 300));
    }
    return null;
  };

  const aliasByCode = { bo:'Bolivia', cd:'Democratic Republic of the Congo', cg:'Republic of the Congo', ci:'Ivory Coast', cv:'Cape Verde', cz:'Czech Republic', gb:'United Kingdom', ir:'Iran', kp:'North Korea', kr:'South Korea', la:'Laos', md:'Moldova', mk:'North Macedonia', mm:'Myanmar', ru:'Russia', sz:'Eswatini', sy:'Syria', tw:'Taiwan', tz:'Tanzania', tr:'Turkey', us:'United States', va:'Vatican City', ve:'Venezuela', vn:'Vietnam', bn:'Brunei', fm:'Micronesia', ps:'Palestine' };
  const cacheKey = (key) => `cazie_flag_ref_${key}`;
  async function loadCatalog() {
    if (state.catalog) return state.catalog;
    const metaKey = cacheKey('flagpedia-country-list-v2');
    let nameMap;
    try { nameMap = JSON.parse(localStorage.getItem(metaKey) || 'null'); } catch {}
    if (!nameMap || typeof nameMap !== 'object') {
      status('Loading Flagpedia country list…');
      const response = await fetch('https://flagcdn.com/en/codes.json');
      if (!response.ok) throw new Error('Could not load Flagpedia country names (network/CORS).');
      nameMap = await response.json();
      try { localStorage.setItem(metaKey, JSON.stringify(nameMap)); } catch {}
    }
    state.nameMap = nameMap;
    const entries = Object.entries(nameMap).filter(([code]) => /^[a-z]{2}$/.test(code));
    let cursor = 0;
    let loaded = 0;
    const refs = new Array(entries.length);
    const worker = async () => {
      while (cursor < entries.length) {
        const i = cursor++;
        const [code, displayName] = entries[i];
        const name = aliasByCode[code] || displayName.replace(/\s*\([^)]*\)/g, '').trim();
        const variants = [];
        const sources = [
          ['flagpedia', `https://flagcdn.com/${code}.svg`],
          ['flag-icons', `https://raw.githubusercontent.com/lipis/flag-icons/main/flags/4x3/${code}.svg`],
        ];
        for (const [source, url] of sources) {
          const key = cacheKey(`${source}-${code}`);
          let svg = null;
          try { svg = localStorage.getItem(key); } catch {}
          if (!svg) {
            try {
              const res = await fetch(url);
              if (res.ok) {
                svg = await res.text();
                if (svg.includes('<svg')) try { localStorage.setItem(key, svg); } catch {}
              }
            } catch {}
          }
          if (svg?.includes('<svg')) variants.push(svg);
        }
        if (variants.length) refs[i] = { name, code, variants };
        loaded++;
        if (loaded % 24 === 0) status(`Loading flag references… ${loaded}/${entries.length}`);
      }
    };
    await Promise.all(Array.from({ length: 10 }, worker));
    state.catalog = refs.filter(Boolean);
    if (!state.catalog.length) throw new Error('No reference flags loaded. Check your connection and try again.');
    return state.catalog;
  }

  async function fallbackAnswer() {
    // If the flag is rendered in an unexpected way, rotate through the full
    // available country-name list so the game still receives an answer.
    let names = state.catalog?.map((c) => c.name);
    if (!names?.length) {
      try {
        if (!state.nameMap) {
          const response = await fetch('https://flagcdn.com/en/codes.json');
          if (response.ok) state.nameMap = await response.json();
        }
        names = Object.entries(state.nameMap || {})
          .filter(([code]) => /^[a-z]{2}$/.test(code))
          .map(([code, name]) => aliasByCode[code] || name.replace(/\s*\([^)]*\)/g, '').trim());
      } catch {}
    }
    if (!names?.length) names = ['United States', 'China', 'India', 'Brazil', 'Japan', 'Nigeria', 'France', 'Italy', 'Canada', 'Australia'];
    const answer = names[state.fallbackIndex % names.length];
    state.fallbackIndex++;
    try { localStorage.setItem('cazie_flag_fallback_index', String(state.fallbackIndex)); } catch {}
    return answer;
  }

  function svgMarkupToPixels(markup) {
    return new Promise((resolve, reject) => {
      const parsed = new DOMParser().parseFromString(markup, 'image/svg+xml');
      const root = parsed.documentElement;
      const viewBox = root.getAttribute('viewBox')?.trim().split(/[ ,]+/).map(Number);
      if (viewBox?.length === 4 && viewBox[2] > 0 && viewBox[3] > 0) {
        root.setAttribute('width', String(viewBox[2]));
        root.setAttribute('height', String(viewBox[3]));
        root.setAttribute('preserveAspectRatio', 'none');
        markup = new XMLSerializer().serializeToString(root);
      }
      const blob = new Blob([markup], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const image = new Image();
      image.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          canvas.width = canvas.height = 48;
          const ctx = canvas.getContext('2d', { willReadFrequently: true });
          ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, 48, 48);
          // The game normalizes its flag drawings into a square SVG viewBox;
          // compare each reference in that same square coordinate space.
          ctx.drawImage(image, 0, 0, 48, 48);
          URL.revokeObjectURL(url);
          resolve(ctx.getImageData(0, 0, 48, 48).data);
        } catch (e) { URL.revokeObjectURL(url); reject(e); }
      };
      image.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Could not rasterize a flag SVG.')); };
      image.src = url;
    });
  }

  async function recognizeFlag() {
    const flagFrame = [...document.querySelectorAll('div')].find((el) =>
      typeof el.className === 'string' && el.className.includes('aspect-3/2') && el.className.includes('max-w-[280px]') && el.querySelector('svg, img')
    );
    const visibleSvgs = [...document.querySelectorAll('svg[viewBox]')].filter((el) => {
      if (el.closest('#cazie-flag-helper')) return false;
      if (!el.getClientRects().length) return false;
      const viewBox = el.getAttribute('viewBox')?.trim().split(/[ ,]+/).map(Number);
      if (viewBox?.length !== 4 || !(viewBox[2] > 0 && viewBox[3] > 0)) return false;
      const cls = typeof el.className?.baseVal === 'string' ? el.className.baseVal : String(el.getAttribute('class') || '');
      if (/lucide|icon/i.test(cls)) return false;
      return true;
    });
    const inFlagFrame = flagFrame ? visibleSvgs.filter((el) => flagFrame.contains(el)) : [];
    const svg = inFlagFrame[0] || visibleSvgs
      .map((el) => ({ el, rect: el.getBoundingClientRect() }))
      .filter(({ rect }) => rect.width >= 100 && rect.height >= 80)
      .sort((a, b) => b.rect.width * b.rect.height - a.rect.width * a.rect.height)[0]?.el;
    if (!svg) throw new Error('Could not find the displayed flag SVG.');
    const target = await svgMarkupToPixels(svg.outerHTML);
    const refs = await loadCatalog();
    const scores = [];
    for (const ref of refs) {
      let bestError = Infinity;
      for (const variant of ref.variants) {
        try {
          const pixels = await svgMarkupToPixels(variant);
          let total = 0;
          for (let i = 0; i < target.length; i += 4) {
            total += Math.abs(target[i] - pixels[i]) + Math.abs(target[i + 1] - pixels[i + 1]) + Math.abs(target[i + 2] - pixels[i + 2]);
          }
          bestError = Math.min(bestError, total / (target.length / 4 * 3));
        } catch {}
      }
      if (Number.isFinite(bestError)) scores.push({ name: ref.name, error: bestError });
    }
    scores.sort((a, b) => a.error - b.error);
    const best = scores[0];
    if (!best) throw new Error('Could not compare this flag with the available references.');
    const runnerUp = scores[1];
    const similarity = Math.max(0, Math.round(100 * (1 - best.error / 100)));
    const ambiguous = best.error > 20 || (runnerUp && runnerUp.error - best.error < 2.5);
    return { name: best.name, confidence: similarity, error: best.error, ambiguous };
  }

  function stopWithMessage(message) {
    state.running = false;
    $('[data-start]').disabled = false;
    $('[data-pause]').disabled = true;
    status(message);
  }

  async function run() {
    if (state.busy || !state.running) return;
    state.busy = true;
    try {
      while (state.running) {
        if (!isChallenge()) { status('Open the Country Flag Challenge to begin.'); await delay(); continue; }
        const input = await waitFor(() => {
          const el = document.querySelector('#flag-country-input');
          return el && !el.disabled && el.offsetParent !== null ? el : null;
        });
        if (!input) break;
        let answer = state.queue.shift();
        if (!answer && $('[data-auto]').checked) {
          status('Recognizing the current flag…');
          let match;
          try {
            match = await recognizeFlag();
            answer = match.name;
            status(`${match.ambiguous ? 'Low-confidence best match' : 'Matched'}: ${answer} (${match.confidence}% pixel similarity). Typing anyway…`);
          } catch (e) {
            answer = await fallbackAnswer();
            status(`Flag image unavailable (${e.message}). Submitting fallback guess “${answer}” and continuing…`);
          }
          if (!state.running) break;
        }
        if (!answer) { stopWithMessage('No answer queued. Enable recognition or add answers.'); break; }
        input.focus();
        const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
        setter.call(input, answer);
        input.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: answer }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        // React-controlled inputs can ignore synthetic edits on some builds.
        // Do not consume the queue or submit unless the displayed value sticks.
        await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
        if (input.value.trim() !== answer) {
          state.queue.unshift(answer);
          state.running = false;
          $('[data-start]').disabled = false;
          $('[data-pause]').disabled = true;
          status('Typing was blocked by the page. Click the game input once, then Start again.');
          break;
        }
        await delay();
        if (!state.running) break;
        const form = input.closest('form');
        const submit = form?.querySelector('button[type="submit"]');
        if (!submit || submit.disabled) {
          state.queue.unshift(answer);
          state.running = false;
          $('[data-start]').disabled = false;
          $('[data-pause]').disabled = true;
          status('The game did not accept the typed answer. Click its input once, then Start again.');
          break;
        }
        status(`Submitting “${answer}”…`);
        submit.click();
        const result = await waitFor(() => {
          const text = [...document.querySelectorAll('form ~ div span, [role="status"], .text-emerald-800, .text-rose-800')]
            .map((el) => el.textContent.trim()).find((t) => /correct|incorrect|right answer|wrong answer/i.test(t));
          const next = [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === 'Next Flag');
          return next ? { text: text || 'Answer evaluated', next } : null;
        });
        if (!result || !state.running) break;
        log(answer, result.text);
        status(`${result.text} Waiting ${state.delay / 1000}s before next flag.`);
        await delay();
        if (!state.running) break;
        result.next.click();
        status('Waiting for the next flag to load…');
        await waitFor(() => {
          const nextInput = document.querySelector('#flag-country-input');
          return nextInput && !nextInput.disabled && nextInput.value === '' ? nextInput : null;
        });
        await delay();
      }
    } finally {
      state.busy = false;
      if (state.running) window.setTimeout(run, 1000);
    }
  }

  const flowClicks = new Map();
  let lastLoginAttempt = '';
  let lastActivationAttempt = '';
  let reloadTimer = 0;
  let loginSubmitTimer = 0;
  const PENDING_KEY = 'cazie_auto_flow_pending_v1';
  const RETRY_KEY = 'cazie_auto_flow_retry_v1';
  const VERIFY_KEY = 'cazie_session_verification_since_v1';
  const getSession = (key) => { try { return JSON.parse(sessionStorage.getItem(key) || 'null'); } catch { return null; } };
  const putSession = (key, value) => { try { sessionStorage.setItem(key, JSON.stringify(value)); } catch {} };
  const clearSession = (key) => { try { sessionStorage.removeItem(key); } catch {} };
  function clearPendingFlow() {
    clearSession(PENDING_KEY);
    clearSession(RETRY_KEY);
    if (reloadTimer) clearTimeout(reloadTimer);
    reloadTimer = 0;
  }
  function fallbackFreshNavigation() {
    const freshUrl = new URL(location.href);
    freshUrl.searchParams.set('__cazie_retry', String(Date.now()));
    location.replace(freshUrl.href);
  }
  function requestFreshReload() {
    // The extension content-script build can request a real cache-bypass
    // reload from its service worker. A standalone userscript uses a URL buster.
    if (typeof chrome !== 'undefined' && chrome.runtime?.id && chrome.runtime.sendMessage) {
      const fallbackTimer = window.setTimeout(fallbackFreshNavigation, 2000);
      try {
        chrome.runtime.sendMessage({ type: 'CAZIE_HARD_REFRESH' }, () => {
          if (chrome.runtime.lastError) {
            clearTimeout(fallbackTimer);
            fallbackFreshNavigation();
          }
        });
        return;
      } catch {}
      clearTimeout(fallbackTimer);
    }
    fallbackFreshNavigation();
  }
  function retryRefresh(kind) {
    if (reloadTimer) return;
    const retry = getSession(RETRY_KEY) || { count: 0 };
    const waitMs = Math.min(120000, 5000 * (2 ** Math.min(retry.count || 0, 5)));
    retry.count = (retry.count || 0) + 1;
    retry.kind = kind;
    putSession(RETRY_KEY, retry);
    status(`${kind === 'activation' ? 'Activation' : 'Login'} is still pending. Hard-refreshing in ${Math.ceil(waitMs / 1000)}s and retrying…`);
    reloadTimer = window.setTimeout(requestFreshReload, waitMs);
  }
  function handleRejectedAuth(kind) {
    const retry = getSession(RETRY_KEY) || { count: 0 };
    // Repeating a rejected password/code can trigger account lockout. Retry a
    // few times for a transient response, then leave the form available.
    if ((retry.rejected || 0) >= 4) {
      clearSession(PENDING_KEY);
      retry.blocked = true;
      putSession(RETRY_KEY, retry);
      status(`${kind === 'activation' ? 'Activation code' : 'Login'} was rejected repeatedly. Check the code/credentials; automation is waiting to avoid an account lockout.`);
      return;
    }
    retry.rejected = (retry.rejected || 0) + 1;
    putSession(RETRY_KEY, retry);
    clearSession(PENDING_KEY);
    if (kind === 'login') lastLoginAttempt = '';
    else lastActivationAttempt = '';
    retryRefresh(kind);
  }
  function explicitAuthFailure(form) {
    const text = `${form?.innerText || ''} ${document.body.innerText || ''}`;
    return /invalid (email|username|password|credentials|activation code|code)|incorrect (email|username|password|credentials|activation code|code)|wrong password|user not found|code (is )?(expired|already used)|too many failed attempts/i.test(text);
  }
  const visible = (el) => !!el && el.isConnected && el.getClientRects().length > 0 && !el.disabled;
  const buttonNamed = (name, scope = document) => [...scope.querySelectorAll('button[type="submit"],button')]
    .find((b) => visible(b) && b.textContent.trim().toLowerCase() === name.toLowerCase());
  const clickFlow = (key, button) => {
    if (!visible(button) || Date.now() - (flowClicks.get(key) || 0) < 5000) return false;
    flowClicks.set(key, Date.now());
    button.click();
    return true;
  };
  function setControlledInput(input, value) {
    if (!input || input.value === value) return;
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
    if (setter) setter.call(input, value); else input.value = value;
    input.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function pauseForAuthPage(kind) {
    // Keep auth/navigation automation active, but stop the flag-answer loop.
    // Do not mark this as a user pause so the challenge can auto-resume later.
    if (state.running) {
      state.running = false;
      $('[data-start]').disabled = false;
      $('[data-pause]').disabled = true;
    }
    status(`Answering paused on the ${kind} page. It will resume automatically when Guess the Flags opens.`);
  }

  function autoNavigate() {
    if (document.visibilityState === 'hidden') return;
    if (isChallenge()) {
      if (loginSubmitTimer) { clearTimeout(loginSubmitTimer); loginSubmitTimer = 0; }
      if (!state.running) {
        if (state.userPaused) return;
        state.running = true;
        $('[data-start]').disabled = true;
        $('[data-pause]').disabled = false;
        status('Flag challenge found. Auto-answering…');
        run();
      }
      return;
    }

    // The app can remain on this server-side session gate without exposing a
    // login or activation form. If it stays there, recover using the same
    // backoff-based fresh navigation used for other stalled auth steps.
    const verifyingSession = /verifying your session|please wait while we securely prepare your account/i.test(document.body?.innerText || '');
    if (verifyingSession) {
      if (loginSubmitTimer) { clearTimeout(loginSubmitTimer); loginSubmitTimer = 0; }
      let since = Number(getSession(VERIFY_KEY) || 0);
      if (!since) {
        since = Date.now();
        putSession(VERIFY_KEY, since);
      }
      const elapsed = Date.now() - since;
      if (elapsed >= 75000) retryRefresh('session verification');
      else status(`The site is verifying your session (${Math.ceil((75000 - elapsed) / 1000)}s before retry)…`);
      return;
    }
    clearSession(VERIFY_KEY);

    const activationInput = [...document.querySelectorAll('input[maxlength="14"],input[placeholder*="CAZIE-"]')]
      .find((input) => input.isConnected && input.getClientRects().length > 0 && /CAZIE-/i.test(input.placeholder || ''));
    if (activationInput) {
      if (loginSubmitTimer) { clearTimeout(loginSubmitTimer); loginSubmitTimer = 0; }
      pauseForAuthPage('activation');
      const form = activationInput.closest('form');
      const verify = form && [...form.querySelectorAll('button[type="submit"],button')]
        .find((b) => /verify activation code/i.test(b.textContent));
      const pending = getSession(PENDING_KEY);
      if (getSession(RETRY_KEY)?.blocked) {
        status('Activation was rejected repeatedly. Check the activation code, then reload after correcting it.');
        return;
      }
      if (pending?.kind === 'activation') {
        if (explicitAuthFailure(form)) {
          handleRejectedAuth('activation');
          return;
        }
        if (Date.now() - pending.startedAt > 20000) {
          retryRefresh('activation');
          return;
        }
        status('Waiting for activation verification…');
        return;
      }
      if (activationInput.value.trim().toUpperCase() !== ACTIVATION_CODE) {
        setControlledInput(activationInput, ACTIVATION_CODE);
        status('Entering the saved activation code…');
        return;
      }
      if (verify && !verify.disabled && lastActivationAttempt !== ACTIVATION_CODE) {
        lastActivationAttempt = ACTIVATION_CODE;
        putSession(PENDING_KEY, { kind: 'activation', startedAt: Date.now() });
        if (clickFlow('activation', verify)) status('Verifying activation code…');
      }
      return;
    }
    if (getSession(PENDING_KEY)?.kind === 'activation') clearPendingFlow();
    lastActivationAttempt = '';

    const password = [...document.querySelectorAll('input[type="password"],input[autocomplete="current-password"]')]
      .find((input) => visible(input));
    if (password) {
      pauseForAuthPage('login');
      const form = password.closest('form');
      const username = form?.querySelector('input[autocomplete="username"],input[type="email"],input[type="text"]');
      const login = form && buttonNamed('LOGIN', form);
      const identity = username?.value?.trim() || '';
      const secret = password.value || '';
      if (getSession(RETRY_KEY)?.blocked) {
        status('Login was rejected repeatedly. Correct the browser-saved credentials, then reload to retry.');
        return;
      }
      if (!identity || !secret) {
        lastLoginAttempt = '';
        status('Waiting for saved browser credentials or manual sign-in. The script does not store your password.');
        return;
      }
      const pending = getSession(PENDING_KEY);
      if (pending?.kind === 'login') {
        if (explicitAuthFailure(form)) {
          handleRejectedAuth('login');
          return;
        }
        if (Date.now() - pending.startedAt > 20000) {
          retryRefresh('login');
          return;
        }
        status('Waiting for sign-in to finish…');
        return;
      }
      const keepLabel = [...(form?.querySelectorAll('label') || [])]
        .find((label) => /keep me signed in/i.test(label.textContent));
      const keepBox = keepLabel?.querySelector('input[type="checkbox"]') || (keepLabel?.htmlFor ? form.querySelector(`#${CSS.escape(keepLabel.htmlFor)}`) : null);
      if (keepBox && !keepBox.checked) {
        keepBox.click();
        status('Selecting “Keep me signed in”…');
        return;
      }
      const attempt = `${identity}\u0000${secret}`;
      if (login && !login.disabled && lastLoginAttempt !== attempt) {
        lastLoginAttempt = attempt;
        const waitMs = 1200 + Math.floor(Math.random() * 1300);
        status(`Credentials are ready. Waiting ${Math.round(waitMs / 1000)}s before submitting login…`);
        loginSubmitTimer = window.setTimeout(() => {
          loginSubmitTimer = 0;
          const currentPassword = form.querySelector('input[type="password"],input[autocomplete="current-password"]');
          const currentUsername = form.querySelector('input[autocomplete="username"],input[type="email"],input[type="text"]');
          if (!form.isConnected || !visible(login) || currentPassword?.value !== secret || currentUsername?.value?.trim() !== identity) {
            lastLoginAttempt = '';
            return;
          }
          putSession(PENDING_KEY, { kind: 'login', startedAt: Date.now() });
          if (clickFlow('login', login)) status('Submitting login…');
          else { clearSession(PENDING_KEY); lastLoginAttempt = ''; }
        }, waitMs);
      }
      return;
    }
    if (loginSubmitTimer) { clearTimeout(loginSubmitTimer); loginSubmitTimer = 0; lastLoginAttempt = ''; }
    if (getSession(PENDING_KEY)?.kind === 'login') clearPendingFlow();
    const flagTitle = [...document.querySelectorAll('h3')]
      .find((el) => el.textContent.trim().toLowerCase() === 'guess the flags');
    if (flagTitle) {
      let card = flagTitle;
      for (let i = 0; i < 8 && card && !buttonNamed('Start Earning', card); i++) card = card.parentElement;
      const start = card && buttonNamed('Start Earning', card);
      if (start && clickFlow('start-flags', start)) status('Opening Guess the Flags…');
      return;
    }

    const categories = buttonNamed('Categories');
    if (categories && clickFlow('categories', categories)) status('Opening Categories…');
  }

  $('[data-delay]').addEventListener('change', (e) => {
    state.delay = Math.max(1000, Math.min(120000, (Number(e.target.value) || 1) * 1000));
    e.target.value = String(state.delay / 1000);
  });
  $('[data-start]').addEventListener('click', () => {
    state.queue = $('[data-answers]').value.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
    state.running = true;
    state.userPaused = false;
    $('[data-start]').disabled = true;
    $('[data-pause]').disabled = false;
    status(state.queue.length ? `${state.queue.length} queued answer(s). Starting…` : 'Starting flag recognition…');
    run();
  });
  function pauseAnswering() {
    state.running = false;
    state.userPaused = true;
    $('[data-start]').disabled = false;
    $('[data-pause]').disabled = true;
    status('Paused.');
  }
  // Capture the control click before any page-level handlers can interfere.
  panel.addEventListener('click', (event) => {
    if (event.target instanceof Element && event.target.closest('[data-pause]')) {
      event.preventDefault();
      event.stopPropagation();
      pauseAnswering();
    }
  }, true);
  window.addEventListener('keydown', (event) => {
    if (event.altKey && event.shiftKey && event.code === 'KeyP' && !event.repeat) {
      event.preventDefault();
      pauseAnswering();
    }
  }, true);
  $('[data-min]').addEventListener('click', () => panel.classList.toggle('min'));
  window[KEY] = { stop: () => $('[data-pause]').click() };
  if (state.running) {
    $('[data-start]').disabled = true;
    $('[data-pause]').disabled = false;
    run();
  }
  autoNavigate();
  window.setInterval(autoNavigate, 900);
  const flowObserver = new MutationObserver(() => autoNavigate());
  flowObserver.observe(document.documentElement, { childList: true, subtree: true });
})();
